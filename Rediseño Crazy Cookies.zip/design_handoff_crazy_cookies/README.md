# Handoff: Rediseño de marca unificado — Crazy Cookies

## Overview
Extiende el sistema de diseño "Dulcerie" (actualmente solo en home/catálogo/detalle/carrito) a las 3 pantallas que hoy rompen la marca: **checkout**, **confirmación de pedido** y **reviews de producto**. Se reemplaza la tipografía serif + Tailwind genérico por un sistema único, minimalista, con una sola familia tipográfica y una paleta reducida. Dirección elegida: **1a — "Cálido y suave"** (esquinas redondeadas, sombra ligera).

## Sobre los archivos de diseño
Los archivos HTML de este paquete (`Crazy Cookies Redesign.dc.html`) son **referencias de diseño**, no código de producción. Muestran el look final y el comportamiento esperado con HTML/CSS inline. La tarea es **recrear este diseño en el stack real del proyecto** (Next.js 14 App Router + TypeScript + Tailwind + SCSS), usando los componentes, tokens de Tailwind y convenciones ya existentes en el código — no copiar el HTML tal cual.

## Fidelidad
**Alta fidelidad (hifi)**: colores, tipografía, espaciado y jerarquía son finales. Implementar pixel-a-pixel con los valores exactos abajo.

## Alcance del cambio
1. Checkout, confirmación de pedido y reviews pasan a compartir el mismo lenguaje visual, tipografía y componentes que home/catálogo/carrito.
2. Estas 3 pantallas deben vivir **dentro del layout con header/footer** (hoy están fuera).
3. La tipografía serif (Cormorant Garamond) desaparece por completo, incluida cualquier referencia en el wordmark — todo pasa a una sola familia sans (Inter).
4. Mobile-first real: sin overflow horizontal, sin elementos cortados en pantallas chicas (360–390px de ancho mínimo).

## Design Tokens

### Tipografía
- Familia única: **Inter** (`font-family: 'Inter', system-ui, sans-serif`), pesos 400/500/600/700/800.
- Escala sugerida (ajustar a la escala de Tailwind existente):
  - Display / título de pantalla: 20–22px / 700
  - Título de producto en card: 12.5–14px / 600
  - Precio destacado: 15–22px / 700–800
  - Cuerpo / secundario: 12.5–13px / 400, color secundario
  - Labels de input: 12px / 500
  - Botones: 13–14px / 600

### Color
| Token | Hex | Uso |
|---|---|---|
| `bg` | `#FAF9F5` | Fondo de página |
| `surface` | `#FFFFFF` | Cards, inputs, superficies elevadas |
| `ink` (texto primario) | `#1A1714` | Texto principal, headings |
| `secondary` (texto secundario) | `#736B62` | Texto de apoyo, metadata |
| `border` | `#E8E2D8` | Bordes de cards/inputs, separadores |
| `accent` | `#C4956A` | CTAs primarios, precios, iconos activos, badges |
| `accentDark` | `#A97748` | Hover/active de accent |
| `success` | `#7C8F6B` | Estado "confirmado" / badge "en curso" — verde salvia desaturado, NO el verde default de Tailwind |
| `error` | `#B24B3C` | Validación de formularios / estados de error |
| `whatsapp` | `#3FA34D` | Único uso: botón "Confirmar por WhatsApp" (reconocible como affordance de marca externa) |

Nota: eliminar por completo grises/azules/verdes default de Tailwind (`gray-*`, `blue-*`, `green-*` de paleta estándar) de checkout/confirmación/reviews — reemplazar por los tokens de esta tabla.

### Forma / elevación (dirección 1a)
- `border-radius`: 14px en cards y botones grandes, 8–10px en elementos internos (imagen de producto, botón +), 999px en chips/pills de filtro y badges de estado.
- `shadow`: `0 2px 16px rgba(26,23,20,.07)` en cards elevadas (product card, order summary). Inputs y botones secundarios sin shadow, solo borde 1.5px `border`.
- `border`: 1px `border` en cards/separadores; 1.5px en inputs y botones secundarios (outline).

### Espaciado
- Padding de card: 14–24px según densidad.
- Gap interno estándar: 8–14px.
- Grid de catálogo/favoritos: 2 columnas en mobile, gap 12px.

## Componentes clave

### Botón primario
`background: var(--accent)`, texto blanco 600 13–14px, padding `12px 20–22px`, `border-radius: 14px`, sin borde. Hover → `accentDark`.

### Botón secundario (outline)
`background: transparent`, texto `ink`, borde `1.5px solid var(--border)`, mismo padding/radius que el primario.

### Input
Padding `12px 14px`, `border-radius: 14px`, borde `1.5px solid var(--border)`, fondo `surface`, label 500 12px arriba. Focus → borde `accent`. Error → borde `error` + texto de ayuda en `error`.

### Product card
Card `surface` + `border` + `shadow`, radius 14px, padding 10–14px. Contiene: imagen (placeholder rayado hasta tener foto real, radius 8–12px), nombre (600, 12.5–14px), precio (700, 13–15px) y botón "+" compacto (accent, radius 8–10px) o CTA completo "Agregar al carrito".

### Order summary card (checkout / confirmación)
Card `surface` + `border`, radius 12–14px, padding 14px. Lista de líneas `nombre × cantidad` (secondary, 12.5px) vs precio (ink, 600, 12.5px) alineadas en `justify-content: space-between`; separador y fila de "Total" en 700–800 al final. En checkout incluye link "Editar carrito" en `accent`.

### Header / Nav
`surface` + borde inferior `border`. Wordmark "Crazy Cookies" en Inter 800 19px (sin serif). Iconos de favoritos y carrito (line icons, stroke `ink`), badge de cantidad en `accent` circular. Nav secundaria (Catálogo / Favoritos / Buscar pedido / Nosotros) en una fila scrolleable en mobile.

### Step indicator (checkout)
3 pasos — "Datos / Revisión / Confirmar" — línea de 2px: `accent` para completado, `border` para pendiente; label activo en 700 `ink`, resto en 500 `secondary`.

## Pantallas

1. **Header/Nav** — persistente en las 3 pantallas que hoy están fuera del layout.
2. **Catálogo** — chips de filtro (pill), grid 2 cols de product cards.
3. **Detalle de producto + reviews** — imagen grande, rating con estrellas en `accent` (glifos `★`, no íconos custom), lista de reviews (autor + estrellas + texto), CTA "Escribir una reseña" (botón secundario).
4. **Carrito** — filas producto + stepper de cantidad (pill outline), subtotal/total, CTA "Ir a checkout".
5. **Checkout** — step indicator, order summary de solo lectura con link "Editar carrito", bloque de entrega, input de cupón + botón "Aplicar", total, CTA "Confirmar pedido".
6. **Confirmación de pedido** — ícono de check en círculo `success`, número de pedido, order summary, botón "Confirmar por WhatsApp" (`whatsapp`, ícono + texto), botón secundario "Volver al catálogo".
7. **Buscar mi pedido** — inputs de número de pedido + correo, botón "Buscar pedido", resultado con badge de estado (`success`, pill).
8. **Favoritos** — grid 2 cols de product cards con ícono de corazón relleno (`accent`) arriba a la derecha.

## Interacciones y comportamiento
- Stepper de cantidad en carrito: +/- deshabilita el "-" en cantidad 1.
- Cupón: botón "Aplicar" pasa a estado de error (borde `error` + mensaje) si el código no existe; éxito muestra línea de descuento en el order summary.
- Checkout: paso "Revisión" es de solo lectura; "Editar carrito" vuelve al carrito.
- Confirmación: "Confirmar por WhatsApp" abre `https://wa.me/<numero>?text=<mensaje con número de pedido>` en nueva pestaña/app.
- Reviews: formulario "Escribir una reseña" — selector de estrellas 1–5 + textarea, validación simple (rating requerido).
- Responsive: todo el contenido en columna única en <480px; catálogo/favoritos mantienen grid 2 cols hasta ~340px de ancho de viewport, luego pasan a 1 col.

## Assets
Placeholders de imagen: patrón rayado diagonal (`repeating-linear-gradient` con `border`/`surface`) + label monoespaciado "foto producto" — reemplazar por fotografía real de producto al implementar. Íconos (corazón, carrito, check, WhatsApp) son SVG lineales simples — usar el set de íconos que ya existan en el proyecto (p. ej. lucide-react) con el mismo peso visual.

## Archivos
- `Crazy Cookies Redesign.dc.html` — prototipo con las 3 direcciones visuales exploradas (1a/1b/1c) y el flujo completo mockeado en 1a.
- `screenshots/` — captura por pantalla del flujo 1a: `01-header-nav`, `02-catalogo`, `03-detalle-reviews`, `04-carrito`, `05-checkout`, `06-confirmacion-whatsapp`, `07-buscar-pedido`, `08-favoritos`.
